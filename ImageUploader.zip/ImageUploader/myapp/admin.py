from django.contrib import admin
from .models import Image # import models.py file
# Register your models here.
@admin.register(Image) # register 'Image' class in admin panel

class ImageAdmin(admin.ModelAdmin):
    # display neccesary variables 
    list_display=['id','photo','date','name']
    
