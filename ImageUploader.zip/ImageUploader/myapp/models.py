from django.db import models
import datetime
# Create your models here.
class Image(models.Model):
    photo=models.ImageField(upload_to='images')# upload images in the 'images' folder
    date=models.DateTimeField(auto_now_add=True)
    name=models.CharField(max_length=100)

# in this file i have create 3 variables i.e 
# photo- uploding images
# date- set date & time
# name- provide image name 